Konkani(Kōṅkaṇī) is an Indo-Aryan language belonging to the Indo-European family of languages and is spoken along the western coast of India. It is one of the 22 scheduled languages mentioned in the 8th schedule of the Indian Constitution and the official language of the Indian state of Goa. The first Konkani inscription is dated 1187 A.D. It is a minority language in Maharashtra, Karnataka, northern Kerala (Kasaragod district) Dadra and Nagar Haveli, and Daman and Diu.

Konkani is a member of the southern Indo-Aryan language group. It retains elements of Old Indo-Aryan structures[citation needed] and shows similarities with both western and eastern Indo-Aryan languages [Refrence: https://en.wikipedia.org/wiki/Konkani_language]

I would like to contribute a part of speech tagged corpus in konkani.

NLTK Name: konkani
Corpus reader: TaggedCorpusReader
Source: I have collected the corpus from various sources like newspapers, magazines, periodicals, academic texts
Author: Prof. Annie Rajan. Associate Professor. Dhempe College of Arts And Science, Goa University
The corpus is freely redistributable
